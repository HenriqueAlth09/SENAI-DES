const usuarios = require("../data/usuarios.data");

//Req -> Request(requisição)
//Res -> Response(resposta)
const listar = (req, res) => {
    res.status(200).send(usuarios).end();
};

const buscar = (req, res) => {
    //   /usuarios/id
    const idUsuario = req.params.id;

var user = "não encontrado";

usuarios.forEach((usuario, index) => {
    if(usuario.id === idUsuario) {
        user = usuario;
    }
});

    res.send(user).end();
};

module.exports = {
    listar,
    buscar
};