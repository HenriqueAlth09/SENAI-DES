const playlist = [
    {
        "id":"123",
        "nome":"Playlist 1",
        "tempo":"20 horas"
    },
    {
        "id":"456",
        "nome":"playlist 2",
        "tempo":"13 horas"
    }
];

module.exports = playlist;