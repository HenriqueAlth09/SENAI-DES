const playlist_musicas = [
    {
        "id":"123",
        "nome":"Plalyist 1",
        "musica 1":"Diario de um detento",
        "musica 2":"Vida loka prt2"
    },
    {
        "id":"456",
        "nome":"Playlist 2",
        "musica 1":"Deixe-me ir",
        "musica 2":"Poesia Acustica 1"
    }
];

module.exports = playlist_musicas;