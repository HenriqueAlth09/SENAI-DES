const usuarios = [
    {
        "id":"123",
        "nome":"Fulano da silva",
        "telefone":"(19) 91234-5678"
    },
    {
        "id":"789",
        "nome":"Beltrano nascimento",
        "telefone":"(19) 94568-7894"
    }
];

module.exports = usuarios;