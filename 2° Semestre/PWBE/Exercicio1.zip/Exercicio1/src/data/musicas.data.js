const musicas = [
    {
        "id":"123",
        "nome":"Eduardo e Monica",
        "artista":"Legião Urbana"
    },
    {
        "id":"456",
        "nome":"Era Um Garoto",
        "artista":"Engenheiros do Hawai"
    },
    
];

module.exports = musicas;